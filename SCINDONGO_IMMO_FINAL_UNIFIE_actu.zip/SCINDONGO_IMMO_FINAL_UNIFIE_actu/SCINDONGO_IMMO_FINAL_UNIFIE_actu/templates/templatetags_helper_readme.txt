For production, you may want to add a generic template filter to style form fields.
